# Metrics Summary

## baseline
- samples: 734
- accuracy: 0.8065
- macro-F1: 0.8082

Confusion matrix (rows=true, cols=pred):
```
[[190  43   5]
 [ 41 193  21]
 [  7  25 209]]
```

## Logged Runs
- baseline/tfidf-logreg: macro-F1=0.8057244174688569 (TF-IDF + LogReg baseline)
- baseline-grid/tfidf-charwb_3_5: macro-F1=0.8081775345797233 (GridSearchCV 5-fold; best_params={'clf__C': 2.0, 'clf__class_weight': 'balanced'})
- baseline/tfidf-logreg: macro-F1=0.8057244174688569 (TF-IDF + LogReg baseline)